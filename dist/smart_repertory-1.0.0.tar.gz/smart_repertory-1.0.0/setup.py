from distutils.core import setup

setup(
	name	= 'smart_repertory',
	version	= '1.0.0',
	py_modules = ['buzzer'],
	author	= 'spock',
	
)
